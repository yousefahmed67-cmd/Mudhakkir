#!/usr/bin/env bash
# Local build (needs Node 22, JDK 21 and the Android SDK; ANDROID_HOME must be set)
set -e
npm install
[ -d android ] || npx cap add android
node scripts/setup-android.js
npx cap sync android
cd android && chmod +x gradlew && ./gradlew assembleDebug
echo "APK: android/app/build/outputs/apk/debug/app-debug.apk"
