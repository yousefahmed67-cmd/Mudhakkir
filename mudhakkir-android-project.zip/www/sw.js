const V='mz-v4',FONTS='mz-fonts';
const CORE=['./','index.html','manifest.webmanifest','icons/icon-96.png','icons/icon-192.png','icons/icon-512.png','icons/favicon-32.png','icons/favicon-48.png','icons/apple-touch-icon.png','icons/badge-96.png','sounds/adhan.mp3','data/quran.json'];
self.addEventListener('install',e=>{self.skipWaiting();e.waitUntil(caches.open(V).then(c=>Promise.all(CORE.map(u=>c.add(u).catch(()=>{})))))});
self.addEventListener('activate',e=>e.waitUntil(Promise.all([self.clients.claim(),caches.keys().then(k=>Promise.all(k.filter(x=>x!==V&&x!==FONTS).map(x=>caches.delete(x))))])));
/* stale-while-revalidate: open instantly from cache, refresh quietly in the background */
function swr(req,name,fallback){return caches.open(name).then(c=>c.match(req,{ignoreSearch:true}).then(hit=>{
 const net=fetch(req).then(res=>{if(res&&(res.ok||res.type==='opaque'))c.put(req,res.clone());return res}).catch(()=>null);
 if(hit){net.catch(()=>{});return hit}
 return net.then(r=>r||(fallback?c.match(fallback):Response.error()))}))}
self.addEventListener('fetch',e=>{const r=e.request;if(r.method!=='GET')return;const u=new URL(r.url);
 if(u.hostname==='fonts.googleapis.com'||u.hostname==='fonts.gstatic.com'){e.respondWith(swr(r,FONTS));return}
 if(u.origin!==location.origin)return;
 if(r.headers.has('range'))return; /* media range requests go straight to the network */
 e.respondWith(swr(r,V,r.mode==='navigate'?'index.html':null))});
self.addEventListener('notificationclick',e=>{e.notification.close();
 e.waitUntil(self.clients.matchAll({type:'window',includeUncontrolled:true}).then(l=>{
  for(const c of l){if('focus' in c)return c.focus()}
  return self.clients.openWindow((e.notification.data&&e.notification.data.url)||'./')}))});
