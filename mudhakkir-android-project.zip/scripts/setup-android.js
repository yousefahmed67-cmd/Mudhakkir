// Runs after `npx cap add android`: copies the icons / adhan sounds / theme and patches the manifest.
const fs = require('fs'), path = require('path');
const root = path.join(__dirname, '..');
const res = path.join(root, 'android', 'app', 'src', 'main', 'res');
const manifestPath = path.join(root, 'android', 'app', 'src', 'main', 'AndroidManifest.xml');
if (!fs.existsSync(manifestPath)) { console.error('android/ not found — run: npx cap add android'); process.exit(1); }

function copyDir(from, to) {
  fs.mkdirSync(to, { recursive: true });
  for (const f of fs.readdirSync(from)) {
    const a = path.join(from, f), b = path.join(to, f);
    fs.statSync(a).isDirectory() ? copyDir(a, b) : fs.copyFileSync(a, b);
  }
}
// 1) resources (icons, splash, adhan sounds in res/raw, styles)
copyDir(path.join(root, 'android-res'), res);
// the template ships its own adaptive-icon vectors; ours (PNG) replace them
for (const f of ['drawable/ic_launcher_background.xml', 'drawable-v24/ic_launcher_foreground.xml']) {
  const p = path.join(res, f); if (fs.existsSync(p)) fs.unlinkSync(p);
}

// 2) manifest permissions
let m = fs.readFileSync(manifestPath, 'utf8');
const perms = [
  'android.permission.POST_NOTIFICATIONS',
  'android.permission.USE_EXACT_ALARM',
  'android.permission.RECEIVE_BOOT_COMPLETED',
  'android.permission.VIBRATE',
  'android.permission.WAKE_LOCK',
  'android.permission.ACCESS_COARSE_LOCATION',
  'android.permission.ACCESS_FINE_LOCATION',
];
const add = perms.filter(p => !m.includes(p)).map(p => `    <uses-permission android:name="${p}" />`).join('\n');
if (add) m = m.replace(/<\/manifest>\s*$/, add + '\n</manifest>\n');
fs.writeFileSync(manifestPath, m);

// 3) target SDK 34 keeps the classic (non edge-to-edge) layout, version code from CI run number
const vars = path.join(root, 'android', 'variables.gradle');
if (fs.existsSync(vars)) {
  let v = fs.readFileSync(vars, 'utf8').replace(/targetSdkVersion\s*=\s*\d+/, 'targetSdkVersion = 34');
  fs.writeFileSync(vars, v);
}
const appGradle = path.join(root, 'android', 'app', 'build.gradle');
if (fs.existsSync(appGradle)) {
  let g = fs.readFileSync(appGradle, 'utf8');
  const code = process.env.VERSION_CODE || '1';
  g = g.replace(/versionCode\s+\d+/, 'versionCode ' + code).replace(/versionName\s+"[^"]*"/, 'versionName "1.0.' + code + '"');
  if (!/core-splashscreen/.test(g)) g = g.replace(/dependencies\s*\{/, 'dependencies {\n    implementation "androidx.core:core-splashscreen:1.0.1"');
  fs.writeFileSync(appGradle, g);
}
console.log('Android project prepared.');
